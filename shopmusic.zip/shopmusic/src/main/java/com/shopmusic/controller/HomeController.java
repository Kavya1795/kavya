package com.shopmusic.controller;

import java.security.Principal;

import javax.servlet.http.HttpServletRequest;
import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

import com.shopmusic.model.Customer;
import com.shopmusic.service.CustomerService;


@Controller
public class HomeController
{
	@Autowired
	CustomerService customerService;
	@RequestMapping("/")
	public ModelAndView home() {
		System.out.println("home() method called");
		return new ModelAndView("home");
		
	}
	
@RequestMapping("/signUp")
public ModelAndView signUp(){
	System.out.println("signUp(); method called");
Customer customer=new Customer();
	return new ModelAndView("signUp","cust",customer);	
}

@RequestMapping("/login")
public String loginMethod()
{
	System.out.println(" I am in login");
	return "login";
}

@RequestMapping("/logout")
public String logout(HttpServletRequest request)
{
	request.getSession().invalidate();
	System.out.println("logout page called");

	return "logout";
	
}
@RequestMapping("/CustomerCheck")
public ModelAndView customerCheck(Principal principal)
{
	System.out.println("UserName"+principal.getName());
	return new ModelAndView("customerHome");
	
	
}
@RequestMapping("/AdminCheck")
public ModelAndView adminCheck(Principal principal)
{
	System.out.println("UserName"+principal.getName());
	return new ModelAndView("adminHome");
	
	
}

@RequestMapping("/register")
public ModelAndView register(@Valid@ModelAttribute("cust") Customer customer ,BindingResult br)

{
	
	if(br.hasErrors())
	{
		return new ModelAndView("signUp");
	}
	System.out.println("UserName:"+customer.getUsername());
	System.out.println("Password:"+customer.getPassword());
	System.out.println("EmailId:"+customer.getEmailId());
	customerService.addCustomer(customer);
	return new ModelAndView("signUp");

	
}
}