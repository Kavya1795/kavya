package com.niit.musicstore.controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.*;

@Controller
public class HomeController {
	ModelAndView mv;
	@RequestMapping(value="/")
	public ModelAndView getHome()
	{
		mv = new ModelAndView("Home");
		return mv;
		
	}

}
