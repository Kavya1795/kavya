package com.shopmusic.service;



import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.shopmusic.dao.ItemDao;
import com.shopmusic.model.Item;

@Service
public class ItemServiceImpl implements ItemService {
	@Autowired
	ItemDao itemDao;

	@Override
	public void addProduct(Item item) {
		itemDao.addProduct(item);
		
	}

	@Override
	public List<Item> viewItem() {
		
		return itemDao.viewItem();
	}

	


}
	